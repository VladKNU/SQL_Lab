﻿using System;
using System.Collections.Generic;

namespace BookStore
{
    public partial class Author
    {
        public Author()
        {
            IdBooks = new HashSet<Book>();
        }

        public int Id { get; set; }
        public string Name { get; set; } = null!;

        public virtual ICollection<Book> IdBooks { get; set; }
    }
}
