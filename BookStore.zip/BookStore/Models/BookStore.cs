﻿using System;
using System.Collections.Generic;

namespace BookStore
{
    public partial class BookStore
    {
        public BookStore()
        {
            Books = new HashSet<Book>();
            Employees = new HashSet<Employee>();
        }

        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string Address { get; set; } = null!;
        public string PhoneNumber { get; set; } = null!;
        public string EMail { get; set; } = null!;

        public virtual ICollection<Book> Books { get; set; }
        public virtual ICollection<Employee> Employees { get; set; }
    }
}
