﻿using System;
using System.Collections.Generic;

namespace BookStore
{
    public partial class Order
    {
        public Order()
        {
            IdBooks = new HashSet<Book>();
        }

        public int Id { get; set; }
        public int IdClient { get; set; }
        public int IdDelivery { get; set; }
        public int IdEmployee { get; set; }
        public DateTime OrderDate { get; set; }

        public virtual Client IdClientNavigation { get; set; } = null!;
        public virtual Delivery IdDeliveryNavigation { get; set; } = null!;
        public virtual Employee IdEmployeeNavigation { get; set; } = null!;

        public virtual ICollection<Book> IdBooks { get; set; }
    }
}
