﻿using System;
using System.Collections.Generic;

namespace BookStore
{
    public partial class Delivery
    {
        public Delivery()
        {
            Orders = new HashSet<Order>();
        }

        public int Id { get; set; }
        public string DeliveryName { get; set; } = null!;
        public DateTime Date { get; set; }
        public decimal FullCost { get; set; }
        public string PhoneNumber { get; set; } = null!;

        public virtual ICollection<Order> Orders { get; set; }
    }
}
