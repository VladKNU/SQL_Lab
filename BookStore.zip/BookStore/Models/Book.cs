﻿using System;
using System.Collections.Generic;

namespace BookStore
{
    public partial class Book
    {
        public Book()
        {
            IdAuthors = new HashSet<Author>();
            IdOrders = new HashSet<Order>();
        }

        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public decimal Cost { get; set; }
        public string Type { get; set; } = null!;
        public int IdStore { get; set; }

        public virtual BookStore IdStoreNavigation { get; set; } = null!;

        public virtual ICollection<Author> IdAuthors { get; set; }
        public virtual ICollection<Order> IdOrders { get; set; }
    }
}
