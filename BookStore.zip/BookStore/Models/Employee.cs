﻿using System;
using System.Collections.Generic;

namespace BookStore
{
    public partial class Employee
    {
        public Employee()
        {
            Orders = new HashSet<Order>();
        }

        public int Id { get; set; }
        public int IdStore { get; set; }
        public string FullName { get; set; } = null!;
        public decimal Salary { get; set; }

        public virtual BookStore IdStoreNavigation { get; set; } = null!;
        public virtual ICollection<Order> Orders { get; set; }
    }
}
